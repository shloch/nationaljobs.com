<!--

/*
 * this page fragment contains important contact informations displayed in aside to the contact form
 */-->
<div>         
    <div class="contactInfos">
        <h3 class="contactInfos-title">Adresses</h3>
        <section class="contactInfos-content">

            <div class="custom">
                <p><img  alt="france" height="45" width="47"><br><span><strong>FRANCE</strong></span></p>
                <p><strong>Siège :</strong><br>Normandie Incubation<br>17, rue Claude Bloch - BP 55027<br>14076 Caen Cedex 5</p>
                <p><strong>Pôle technique :</strong><br>Plug'N'Work<br>2 Rue Jean Perrin, 14460 Colombelles</p>
                <p><strong>Etablissement secondaire :</strong><br> Bond'Innov<br>Campus IRD France Nord - 32 avenue Henri Varagnat 93143 Bondy Cedex</p>
                <p><strong>Succursale :<br></strong>QuickDo Cameroun<br>BP&nbsp;15345 Yaoundé</p></div>
        </section>
    </div>

</div>