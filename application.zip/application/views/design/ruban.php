<!--
/*
 * the gray ruban after the top dark ruban
 */-->
<div id="rubanIcons">
    <center>
        <img title="" alt="LOGO" src="<?php echo base_url() ?>images/chat.png" />f
        <img title="" alt="LOGO" src="<?php echo base_url() ?>images/chat.png" />f
        <img title="" alt="LOGO" src="<?php echo base_url() ?>images/chat.png" />f
    </center>
</div>

<div id="rubanIDropDown">

    <div id="top_nav" class="ddsmoothmenu">
        <?php $this->load->view('design/menuDropDown'); ?>
    </div> <!-- end of ddsmoothmenu -->
</div>
