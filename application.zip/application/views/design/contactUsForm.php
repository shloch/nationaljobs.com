<!--
/*
 * contact Us form
 */-->


<h2>Nous contacter</h2>
<form enctype="multipart/form-data" name="FoxForm" class="contactForm" action="">
    <!-- com_foxcontact 2.0.17 1 -->
    Vous souhaitez en savoir plus sur notre activité ou nous rencontrer ?<br/><br/>
    <label>Votre nom <span class="asterisk"></span></label><br/><input  title="Votre nom"  type="text"><br/><br/>
    <label>Votre e-mail <span class="asterisk"></span></label><br/><input  title="Votre e-mail" type="text"><br/><br/>
    <label>Votre numéro de téléphone</label><br/><input  title="Votre numéro de téléphone"  type="text"><br/><br/>

    <label>Décrivez votre demande</label><br/>
    <textarea rows="5" cols="29"  name="comment" title="Describe your demand" ></textarea>


</form>
<div class="cleaner"></div>