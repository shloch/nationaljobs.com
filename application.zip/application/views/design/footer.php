<!--
/*
 * basic footer design
 */-->
<div style="width:auto;">
    <div class="bottomBlocks">
        <div class="bottomBloacksHeader">Kimber Jobs</div>
        <div class="bottomBloacksContent">
            <li><a href="<?php echo base_url() . 'index.php/terms_of_service'; ?>">TERMS OF SERVICE</a></li>
            <li><a href="<?php echo base_url() . 'index.php/contactUs'; ?>">Contact Us</a></li>

            <a href="#">Curabitur sed felis urna, </a><br/>
            <a href="#">Curabitur sed felis urna, </a><br/>
            <a href="#">Curabitur sed felis urna, </a><br/>
            <a href="#">Curabitur sed felis urna, </a><br/>
        </div>
    </div>

    <div class="bottomBlocks">
        <div class="bottomBloacksHeader">Kimber Jobs</div>
        <div class="bottomBloacksContent">
            My first jQuery lets us do this with the css functionjQuery lets us do this with the css function
            jQuery lets us do thisfunction paragraph.<a href="#" title="get more infos"> get more </a>

        </div>
    </div>

    <div class="bottomBlocks">
        <div class="bottomBloacksHeader">Kimber Jobs</div>
        <div class="bottomBloacksContent">
            My first jQuery lets us do this with the css functionjQuery lets us do this with the css function
            jQuery lets us do thisfunction paragraph.<a href="#" title="get more infos"> get more </a>

        </div>
    </div>

    <div class="bottomBlocks">
        <div class="bottomBloacksHeader">Kimber Jobs</div>
        <div class="bottomBloacksContent">
            My first jQuery lets us do this with the css functionjQuery lets us do this with the css function
            jQuery lets us do thisfunction paragraph.<a href="#" title="get more infos"> get more </a>

        </div>
    </div>

    <div class="bottomBlocks">
        <div class="bottomBloacksHeader">Kimber Jobs</div>
        <div class="bottomBloacksContent">
            My first jQuery lets us do this with the css functionjQuery lets us do this with the css function
            jQuery lets us do thisfunction paragraph.<a href="#" title="get more infos"> get more </a>

        </div>
    </div>

</div>

