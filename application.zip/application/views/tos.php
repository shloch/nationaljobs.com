<?php
/*
 * terms of service view page
 */
?>
<link rel="stylesheet" href="<?php echo base_url() ?>css/form.css" media="screen">

<h1>TERMS OF SERVICE</h1>

<h2>History of our online shop</h2>
<p>Nam cursus facilisis nibh nec eleifend. Mauris nulla leo, tempus ac laoreet in, aliquet eu sem. Nullam est est, imperdiet vitae mollis nec, aliquet varius ante. Donec laoreet <a href="#">eleifend velit a tristique</a>. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed vehicula elit vel ante venenatis laoreet.</p>
<ul>
    <li>Donec aliquam metus a odio molestie eu consequat.</li>
    <li>Sed a rutrum risus, nam sed ligula et nunc fermentum.</li>
    <li>Maecenas sit amet diam quis sem euismod porttitor.</li>
    <li>Aliquam fermentum cursus risus aliquam erat volutpat.</li>
    <li>Sed fermentum tempus enim, eget iaculis purus imperdiet eget.</li>
</ul>
<div class="cleaner h20"></div>
<h3>Background of our company</h3>
<p>Nam nec leo. Curabitur quis eros <a href="#">a arcu feugiat</a> egestas. Nunc sagittis, dui non porttitor tincidunt, mi tortor tincidunt sem, et aliquet mi tortor eu turpis. Ut nisi ligula, viverra ac, placerat sed, ultricies vitae, neque. Morbi feugiat neque non odio eleifend pulvinar. In risus lacus, consequat eu porta ac, mattis a lacus. Validate <a href="http://validator.w3.org/check?uri=referer" rel="nofollow"><strong>XHTML</strong></a> &amp; <a href="http://jigsaw.w3.org/css-validator/check/referer" rel="nofollow"><strong>CSS</strong></a>.</p>
<div class="cleaner"></div>
<blockquote>Pellentesque vulputate cursus arcu vel pellentesque. Etiam facilisis imperdiet enim at tempus. Ut tincidunt venenatis est, quis viverra quam scelerisque vel. Aenean eu tellus a arcu blandit lobortis.
</blockquote>