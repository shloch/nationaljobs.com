<?php
/*
 * Edit profile sub page 3
 */
?>
<div class="header_01">Quality Services</div>



<div class="section_w500 fr">
    <p class="em_text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. In quis tortor ut velit suscipit lobortis. Quisque nec massa sapien, nec semper mi. Cras tincidunt posuere tortor vitae blandit.</p>
    <p>Duis vel quam at elit auctor suscipit vitae in dolor. Mauris consequat est a ligula luctus luctus. Aliquam nec metus vel felis consectetur posuere egestas a eros. In arcu tortor, porta vel aliquet in, iaculis quis arcu. Sed eget lacus tortor. Vestibulum tempor purus odio, et posuere tellus.</p>

    <ul class="service_list">
        <li>Proin ullamcorper placerat purus, quis tempus ligula bibendum ut. </li>
        <li>Vivamus augue arcu, lacinia quis varius non, ultrices sit amet tortor.</li>
        <li>Nam vestibulum cursus tortor, suscipit vestibulum lorem sagittis at. </li>
        <li>Donec pretium dapibus nibh, ac ultrices neque pretium sed.</li>
        <li>Maecenas non felis vitae nulla ultrices convallis sed eget quam. </li>
        <li>Sed vulputate libero et tellus lacinia pulvinar.</li>
        <li>Atiam cursus velit nec eros aliquet aliquet.</li>
        <li>Etiam porttitor posuere dui, et imperdiet erat mollis sed. </li>
    </ul>
</div>