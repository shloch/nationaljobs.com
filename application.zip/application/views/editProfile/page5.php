<?php

/*
 * edit profile sub page
 */
?>
 <div class="header_01">Contact Us</div>  

            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi sit amet eros tempor risus tristique laoreet. Nulla eget varius arcu. Etiam nec nunc in sapien aliquet mattis.</p>

            <div class="contact_form">
                <form action="#" method="post">
                    <label>* Name</label><input type="text" class="input_field" />
                    <div class="margin_bottom_20"></div>
                    <label>* Email</label><input type="text" class="input_field" />
                    <div class="margin_bottom_20"></div>
                    <label>Subject</label><input type="text" class="input_field" />
                    <div class="margin_bottom_20"></div>
                    <label>* Message</label><textarea rows="" cols=""></textarea>
                    <div class="margin_bottom_20"></div>
                    <label>&nbsp;</label><input type="submit" name="Send" value="Send" class="submit_btn" /> <input type="submit" name="Cancel" value="Cancel" class="submit_btn" />                                                                          
                </form>
            </div>     