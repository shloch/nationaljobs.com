<?php

/*
 * Edit profile sub page 1
 */
?>
 <div class="header_01">Welcome to Consultant Website</div>
            <h1>TESTING....</h1>

            
            <p class="em_text">This is XHTML/CSS layout provided by <a href="http://www.templatemo.com" target="_parent">TemplateMo.com</a> for free of charge. You may download, edit and apply this template for your websites.</p> 
            <p>Credits go to <a href="http://www.smashingmagazine.com" target="_blank">Smashing Magazine</a> for menu graphic icons and <a href="http://www.photovaco.com" target="_blank">Free Photos</a> for photos. Integer vestibulum, elit non lobortis sodales, dui nibh imperdiet turpis, id lobortis enim turpis eget ante. Donec non magna nunc.</p>
            <p>Etiam vulputate mattis neque in egestas. Donec porta augue a justo consectetur nec fringilla sem feugiat. Vivamus non lacus elit. Duis tortor orci, consequat ac ullamcorper ac, pulvinar et nunc. Curabitur sed massa nulla, quis pellentesque neque. Phasellus euismod congue felis eget lacinia.</p>

            <div class="margin_bottom_40"></div>

            <div class="header_01">Lorem ipsum dolor sit amet</div>

            <div class="image_wrapper image_wrapper_fr">
                <img src="images/templatemo_image_02.jpg" alt="image" />
            </div>
            <p class="em_text">Donec vitae nulla leo. Aliquam erat volutpat. Suspendisse enim massa, iaculis ut aliquet non, placerat non turpis. Aenean condimentum eros sit amet nisl tincidunt consectetur.</p>
            <p>Mauris sed velit massa. Nulla sodales, nunc ut scelerisque pharetra, orci nibh fermentum lectus, vel ullamcorper est mi eget nunc. Donec faucibus, diam et fermentum tincidunt, enim diam pulvinar nisl, sed lacinia ipsum justo quis eros.</p>

            <a href="http://validator.w3.org/check?uri=referer"><img style="border:0;width:88px;height:31px" src="http://www.w3.org/Icons/valid-xhtml10" alt="Valid XHTML 1.0 Transitional" width="88" height="31" vspace="8" border="0" /></a>
            <a href="http://jigsaw.w3.org/css-validator/check/referer"><img style="border:0;width:88px;height:31px"  src="http://jigsaw.w3.org/css-validator/images/vcss-blue" alt="Valid CSS!" vspace="8" border="0" /></a>
