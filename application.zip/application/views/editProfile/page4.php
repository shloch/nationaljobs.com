<?php
/*
 * Edit profile sub page
 */
?>
<div class="header_01">Portfolio</div>

<div class="section_w360 fl margin_right_60">


    <p>flashmo.com provides free flash templates, photo galleries, 3d galleries, etc. </p>
    Website: <a href="http://www.flashmo.com" target="_parent">Free Flash Templates</a>

</div>

<div class="section_w360 fl">

    <div class="image_wrapper">
        <img src="images/templatemo_image_06.jpg" alt="Web Templates" />
    </div>

    <p>TemplateMo.com provides a lot of high quality free css templates for your personal or commercial websites.</p>
    Website: <a href="http://www.templatemo.com" target="_parent">Free CSS Templates</a>

</div>

<div class="margin_bottom_40"></div>

<div class="section_w360 fl margin_right_60">



    <p>Web Design blog sharing useful resources and ideas.</p>
    Website: <a href="http://www.webdesignmo.com/blog" target="_parent">Web Design Blog</a>

</div>

<div class="section_w360 fl">



    <p>Free photos for both personal and commercial projects.</p>
    Website: <a href="http://www.photovaco.com" title="_blank">Free Stock Photos</a>

</div>