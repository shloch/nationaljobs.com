<?php
/*
 * Edit profile sub page 2
 */
?>
<div class="header_01">About Our Company</div>

<p class="em_text">IUt id est id sem aliquet tristique. Praesent congue imperdiet arcu ac euismod. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</p>
<p>Vestibulum eu semper nulla. Nam mi diam, aliquam sed tempus sit amet, cursus nec velit. Sed posuere felis quis elit congue adipiscing et ac nunc. Fusce a lacus vel est malesuada pellentesque ut eget nulla. Nulla eu felis et erat luctus ullamcorper vestibulum quis risus. Pellentesque ipsum ipsum, accumsan eget egestas sit amet, blandit sed erat. Praesent pellentesque rutrum ligula, non cursus mauris dictum a. </p>

<div class="margin_bottom_40"></div>



<div class="section_w500 fr">
    <p>Cras tristique pellentesque tortor, sit amet sodales est eleifend ut. Sed ac lacus leo. In vitae enim et mauris pulvinar pellentesque. Mauris turpis ante, viverra in varius vitae, laoreet a enim. Duis aliquet venenatis interdum. Sed bibendum, risus a sodales pellentesque, dolor dui vehicula leo, at congue lacus ligula quis nulla.</p>
    <p class="em_text">Proin placerat pulvinar suscipit. In ut risus turpis, in feugiat dolor. Praesent placerat commodo velit, nec semper sem consectetur quis. Curabitur auctor, risus id egestas vestibulum, nibh libero congue massa, id lobortis turpis nunc nec nisl. Quisque mauris libero, eleifend et lacinia at, vulputate pellentesque felis. Sed in lorem a massa dictum bibendum. In hac habitasse platea dictumst.</p>
    <p>Quisque at ante sit amet erat laoreet fermentum. Quisque nec nisl. Nam scelerisque cursus dolor. Integer vel sapien quis risus egestas suscipit. Nam lorem tortor, viverra gravida, egestas id, pellentesque in, mi. Maecenas sodales pede eu massa. Fusce lacinia orci at nisi. Suspendisse at nisi nec diam pretium tincidunt. Ut vitae felis eu lectus ultrices varius. Aliquam lacus turpis, dapibus eget, tincidunt eu, lobortis et, magna.</p>
</div>